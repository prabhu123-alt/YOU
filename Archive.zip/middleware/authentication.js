const { validytoken } = require('../services/authentication');

function cookparserforuser(cookieName) {
  return (req, res, next) => {
    const token = req.cookies[cookieName];
    if (!token) return next();

    try {
      const userPayload = validytoken(token);
      req.user = userPayload;
    } catch (error) {
      console.error('Invalid token:', error);
    }
    next();
  };
}

module.exports = {
  cookparserforuser,
};
