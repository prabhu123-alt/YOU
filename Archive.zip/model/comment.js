const { Schema, model } = require('mongoose');

const commentSchem = new Schema({

    Content: {
        type: String,
        required: true,
    },
    blogId:{
        type: Schema.Types.ObjectId,
        ref: 'blog',
    },
    createdBy: {
        type: Schema.Types.ObjectId,
        ref: 'User', 

    },
}, { timestamps: true });

const  Comment= model('comment', commentSchem);
module.exports =Comment;