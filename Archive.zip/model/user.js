const {Schema,model} = require('mongoose');
const crypto = require('crypto');
const { createtokenforuser } = require('../services/authentication');

const userSchema = new Schema({
  fullName: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  salt: {
    type: String,
  },
  password: {
    type: String,
    required: true,
  },
  urlImage: {
    type: String,
    default: '/images/download.png',
  },
  role: {
    type: String,
    enum: ['user', 'admin'],
    default: 'user',
  },
}, { timestamps: true });

userSchema.pre('save', function (next) {
  if (!this.isModified('password')) return next();

  const salt = crypto.randomBytes(16).toString('hex');
  const hashedPassword = crypto.createHmac('sha256', salt)
    .update(this.password)
    .digest('hex');

  this.salt = salt;
  this.password = hashedPassword;

  next();
});

userSchema.statics.matchPasswordForUserToken = async function (email, password) {
  const user = await this.findOne({ email });
  if (!user) throw new Error('User not found!');

  const hashedPassword = crypto.createHmac('sha256', user.salt)
    .update(password)
    .digest('hex');

  if (user.password !== hashedPassword) throw new Error('Incorrect password!');
  
  return createtokenforuser(user);
};

const User =model('User', userSchema);
module.exports = User;
