const { Schema, model } = require('mongoose');

const blogSchem = new Schema({

    title: {
        type: String,
        required: true,
    },
    body: {
        type: String,
        required: true,
    },
    coverImageURl: {
        type: String,
        required: false,
    },
    createdBy: {
        type: Schema.Types.ObjectId,
        ref: 'User', 

    },
}, { timestamps: true });

const Blog = model('Blog', blogSchem);
module.exports = Blog;