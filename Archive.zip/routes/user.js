const { Router } = require('express');
const User = require('../model/user');

const router = Router();

router.get('/signin', (req, res) => {
  res.render('signin', { error: null }); // Pass default value or null if no error
});

router.get('/signup', (req, res) => {
  res.render('signup', { error: null }); // Pass default value or null if no error
});

router.get('/logout',(req,res)=>{
  res.clearCookie('token').redirect('/');
});

router.post('/signin', async (req, res) => {
  const { email, password } = req.body;

  try {
    const token = await User.matchPasswordForUserToken(email, password);
    res.cookie('token', token).redirect('/');
  } catch (error) {
    console.error(error);
    res.status(401).render('signin', { error: 'Incorrect email or password' });
  }
});

router.post('/signup', async (req, res) => {
  const { fullName, email, password } = req.body;
  try {
    await User.create({ fullName, email, password });
    res.redirect('/user/signin');
  } catch (error) {
    console.error(error);
    res.status(500).render('signup', { error: 'Error signing up' });
  }
});

module.exports = router;
