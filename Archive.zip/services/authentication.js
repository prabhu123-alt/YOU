const JWT = require('jsonwebtoken');

const secret = process.env.JWT_SECRET || '@prabhu120singh--';

function createtokenforuser(user) {
  const payload = {
    _id: user._id,
    email: user.email,
    urlImage: user.urlImage,
    role: user.role,
    fullName:user.fullName,
  };
  return JWT.sign(payload, secret);
}

function validytoken(token) {
  return JWT.verify(token, secret);
}

module.exports = {
  createtokenforuser,
  validytoken,
};
