require('dotenv').config();
const path=require('path');
const express = require('express');
const mongoose = require('mongoose');
const Blog = require('./model/blog');
const cookieParser = require('cookie-parser');
const userRouter = require('./routes/user');
const blogRoute = require('./routes/blog');
const { cookparserforuser } = require('./middleware/authentication');
const app = express();
const PORT = process.env.PORT;
mongoose.connect(process.env.Mongo_URL)
  .then(() => console.log('Successfully connected to MongoDB'))
  .catch(err => console.error('Error connecting to MongoDB:', err));

app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(cookparserforuser('token'));
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'views'));


app.get('/', async (req, res) => {
  try {
    const allBlogs = await Blog.find({});
    res.render('home', {
      user: req.user,
      error: req.query.error,
      blogs: allBlogs,
    });
  } catch (error) {
    console.error('Error rendering home view:', error); 
    res.status(500).send('Internal Server Error');
  }
});
app.use(express.static(path.resolve(__dirname, "public")));



app.use('/user', userRouter);
app.use('/blog', blogRoute);

app.listen(PORT, () => {
  console.log(`Server is running on port: ${PORT}`);
});
